package Biblioteca;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

public class Teste {

    public static void main(String[] args) {
        int opcao = 1;
        ArrayList<Usuario> listaUsuario = new ArrayList();
        ArrayList<Livros> listaLivros = new ArrayList();
        ArrayList<Emprestimo> listaEmprestimo = new ArrayList();
        while (opcao == 1) {
            System.out.println("Menu\n"
                    + "[1] Adicionar usuario\n"
                    + "[2] Pesquisar dados de usuarios\n"
                    + "[3] Listar todos os usuarios\n"
                    + "[4] Adicionar livro\n"
                    + "[5] Pesquisar livro\n"
                    + "[6] Listar todos os livros\n"
                    + "[7] Realizar Empréstimo\n"
                    + "[8]Listar livros não devolvidos\n"
                    + "[9]Lista livros devolvidos\n"
                    + "[0] Sair\n"
            );
            int swit = 0;
            System.out.println("Qual opção você deseja?");
            Scanner sc1 = new Scanner(System.in);

            swit = sc1.nextInt();
            switch (swit) {
                case 1: {
                    Scanner sc3 = new Scanner(System.in);

                    System.out.println("Informe o id:");
                    int id_add = sc3.nextInt();
                    System.out.println("\nInforme o nome:");
                    String nome_add = sc3.next();
                    System.out.println("Informe o email");
                    String email_add = sc3.next();
                    System.out.println("Informe o senha");
                    String senha_add = sc3.next();

                    Usuario u1 = new Usuario(id_add, nome_add, email_add, senha_add);
                    listaUsuario.add(u1);
                    System.out.println("Usuario adicionado");

                    break;
                }
                case 2: {
                    String nome_p;
                    System.out.println("Informe o nome que deseja pesquisar");
                    Scanner pes = new Scanner(System.in);
                    nome_p = pes.next();

                    for (int i = 0; i < listaUsuario.size(); i++) {
                        if (listaUsuario.get(i).getNome().contains(nome_p)) {
                            System.out.println("Usuario encontrado");
                            System.out.println(listaUsuario.get(i));

                        }

                    }

                    break;
                }
                case 3: {

                    for (int i = 0; i < listaUsuario.size(); i++) {
                        System.out.println(listaUsuario.get(i).getNome());
                    }

                    break;
                }
                case 4: {
                    Scanner sc4 = new Scanner(System.in);
                    System.out.println("Informe o id do livro");
                    int id_add2 = sc4.nextInt();
                    System.out.println("Informe o titulo:");
                    String titulo_add = sc4.next();
                    System.out.println("Informe o autor:");
                    String autor_add = sc4.next();
                    System.out.println("\nInforme a edicao:");
                    String edicao_add = sc4.next();
                    System.out.println("Informe a editora");
                    String editora_add = sc4.next();
                    System.out.println("Informe a cidade");
                    String cidade_add = sc4.next();
                    System.out.println("Informe o ano do livro");
                    int anopublicacao_add = sc4.nextInt();

                    Livros l1 = new Livros(id_add2, titulo_add, autor_add, edicao_add, editora_add, cidade_add, anopublicacao_add);
                    listaLivros.add(l1);
                    System.out.println("Livro adicionado");
                    break;
                }
                case 5: {
                    int id_p;
                    System.out.println("Informe o nome do livro que deseja pesquisar");
                    Scanner pes = new Scanner(System.in);
                    id_p = pes.nextInt();

                    for (int i = 0; i < listaLivros.size(); i++) {
                        if (listaLivros.get(i).getId() == id_p) {
                            System.out.println("Livro encontrado");
                            System.out.println(listaUsuario.get(i));

                        }

                    }

                    break;
                }
                case 6: {
                    for (int i = 0; i < listaLivros.size(); i++) {
                        System.out.println(listaLivros.get(i).getTitulo());
                    }

                    break;
                }
                case 7: {
                    Scanner sc5 = new Scanner(System.in);
                    System.out.println("Informe o id do empréstimo");
                    int id_add3 = sc5.nextInt();
                    System.out.println("Informe o id do Usuário:");
                    int idu_add = sc5.nextInt();
                    System.out.println("Informe o id do Livro:");
                    int idl_add = sc5.nextInt();
                    boolean devolvido_add = false;
                    System.out.println("A data de entrega é de 7 dias");
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/uuuu");
                    LocalDate dataEmprestimo_add = LocalDate.parse("12/05/2020", formatter);

                    LocalDate dataDevolucao_add = LocalDate.parse("19/05/2020", formatter);

                    Emprestimo e1 = new Emprestimo(id_add3, idu_add, idl_add, dataEmprestimo_add, dataDevolucao_add, devolvido_add);
                    listaEmprestimo.add(e1);
                    System.out.println("Livro adicionado");
                    break;
                }
                case 8: {
                    for (int i = 0; i < listaEmprestimo.size(); i++) {
                        for (int j = 0; j < listaLivros.size(); j++) {
                            if (listaEmprestimo.get(i).getIdLivro() == listaLivros.get(j).getId() && listaEmprestimo.get(i).isDevolvido() == false) {
                                System.out.println(listaLivros.get(i).getTitulo());
                            }
                        }
                    }

                    break;
                }
                case 9: {
                    for (int i = 0; i < listaEmprestimo.size(); i++) {
                        for (int j = 0; j < listaLivros.size(); j++) {
                            if (listaEmprestimo.get(i).getIdLivro() == listaLivros.get(j).getId() && listaEmprestimo.get(i).isDevolvido() == true) {
                                System.out.println(listaLivros.get(i).getTitulo());
                            }
                        }
                        break;
                    }
                }

                case 0: {
                    System.out.println("Obrigado por usar meu programa");
                    break;

                }
            }

            System.out.println("\nVoltar para o menu?"
                    + " \n para sim digite 1 "
                    + "\n para nao digite 0");
            Scanner sc2 = new Scanner(System.in);
            opcao = sc2.nextInt();
            System.out.println("\r\n");
        }
    }
}
