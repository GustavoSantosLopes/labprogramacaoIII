
package Biblioteca;

import java.time.LocalDate;



public class Emprestimo extends Livros{
    
    private int idUsuario;
    private int idLivro;
    private LocalDate dataEmprestimo;
    private LocalDate dataDevolucao;
    private boolean devolvido;

    public Emprestimo() {
    }

    public Emprestimo(int id,int idUsuario, int idLivro, LocalDate dataEmprestimo, LocalDate dataDevolucao, boolean devolvido) {
        super(id);
        this.idUsuario = idUsuario;
        this.idLivro = idLivro;
        this.dataEmprestimo = dataEmprestimo;
        this.dataDevolucao = dataDevolucao;
        this.devolvido = devolvido;
    }

    /*public Emprestimo(int id,int idUsuario, int idLivro, boolean devolvido) {
        
        super(id);
        this.idUsuario = idUsuario;
        this.idLivro = idLivro;
        this.devolvido = devolvido;
    }*/

    
    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public int getIdLivro() {
        return idLivro;
    }

    public void setIdLivro(int idLivro) {
        this.idLivro = idLivro;
    }

    public LocalDate getDataEmprestimo() {
        return dataEmprestimo;
    }

    public void setDataEmprestimo(int i,int j, int k) {
        LocalDate data;
        data=LocalDate.of(i,j,k);
        this.dataEmprestimo = data;
    }
    public LocalDate getDataDevolucao() {
        return dataDevolucao;
    }

    public void setDataDevolucao(int i,int j, int k) {
        LocalDate data;
        data=LocalDate.of(i,j,k);
        this.dataDevolucao = data;
    }

    public boolean isDevolvido() {
        return devolvido;
    }

    public void setDevolvido(boolean devolvido) {
        this.devolvido = devolvido;
    }

    @Override
    public String toString() {
        return "Emprestimo:\n" + "idUsuario=" + getIdUsuario() + "\n idLivro=" + getIdLivro() + ", dataEmprestimo=" + getDataEmprestimo() + ", dataDevolucao=" + getDataDevolucao() + ", titulo=" + getTitulo() ;
    }
    
}
